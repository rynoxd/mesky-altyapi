const Discord = require(`discord.js`);
const os = require(`os`);
exports.run = async (client, message, args) => {
  
  const up = os.uptime()

    let supports = "https://discord.gg/WjrPnueBEc";
    let website = "https://discord.gg/WjrPnueBEc";

    let link_button = new Discord.ActionRowBuilder().addComponents(
      new Discord.ButtonBuilder()
      .setLabel('📒 Destek Sunucusu')
      .setStyle(Discord.ButtonStyle.Link)
      .setURL(supports),
        new Discord.ButtonBuilder()
        .setLabel('📨 Davet Et')
        .setStyle(Discord.ButtonStyle.Link)
        .setURL(`https://discord.com/api/oauth2/authorize?client_id=1037491323076362321&permissions=8&scope=bot`),
        new Discord.ButtonBuilder()
        .setLabel('🗳 Bota Oy Ver')
        .setStyle(Discord.ButtonStyle.Link)
        .setURL(website));

const cs = new Discord.EmbedBuilder()
.setTitle("<:MEKSYNEWPP:1037718595972648970> Yardım menüsü | MEKSY.js")
.setThumbnail(message.author.avatarURL() ? message.author.avatarURL({dynamic: true}) : 'https://cdn.glitch.com/8e70d198-9ddc-40aa-b0c6-ccb4573f14a4%2F6499d2f1c46b106eed1e25892568aa55.png')
.setColor("#363636")
.setDescription(`
Sende **[MEKSY.js](https://discord.com/api/oauth2/authorize?client_id=1037491323076362321&permissions=8&scope=bot)**'yi Davet Etki
Bukadar Çok Komuttan Faydalanma Şansı Yakala.

<:myicon7:1036329226116288552> **Ticket Sistemi**

+ticket-log \`#kanaletiket\`
> **Ticketin Log Kanalını Ayarlarsın.**
+ticket-yetkili \`@roletiket\`
> **Ticketin Yetkili Rolünü Ayarlarsın.**
+ticket-oluştur \`Buton Yazısı + Embed Yazısı\` **+ durmak zorunda!**
**Ticket Yazısını Ayarlarsın.**

`)
await message.reply({embeds: [cs], components:[link_button]}).catch(async err => {
await message.author.send({embeds: [cs]}).catch(async err => {
return console.log(`**Yardım Komutum Hata Aldı!** \`${message.guild.name}\` **Adlı Sunucuda Yetkim Olmadığı İçin Mesajı Atamıyorum.**`)
})
})

};

exports.conf = {
aliases: ["ticket-sistem", "ticketsistem", "ts"]
};

exports.help = {
name: 'ticket'
};