const Discord = require(`discord.js`);
const os = require(`os`);
exports.run = async (client, message, args) => {
  
  const up = os.uptime()

    let supports = "https://discord.com/api/oauth2/authorize?client_id=1040772266654449725&permissions=8&scope=bot%20applications.commands";
    let website = "https://discord.com/api/oauth2/authorize?client_id=1040772266654449725&permissions=4398046511095&scope=bot%20applications.commands";

    let link_button = new Discord.ActionRowBuilder().addComponents(
      new Discord.ButtonBuilder()
      .setLabel('🔗 Yöneticili Davet')
      .setStyle(Discord.ButtonStyle.Link)
      .setURL(supports),
        new Discord.ButtonBuilder()
        .setLabel('📎 Yetkisiz Davet')
        .setStyle(Discord.ButtonStyle.Link)
        .setURL(`https://discord.com/api/oauth2/authorize?client_id=1040772266654449725&permissions=0&scope=bot%20applications.commands`),
        new Discord.ButtonBuilder()
        .setLabel('🖇 Yöneticisiz Davet')
        .setStyle(Discord.ButtonStyle.Link)
        .setURL(website));

const cs = new Discord.EmbedBuilder()
.setTitle("<:MEKSYNEWPP:1037718595972648970> Davet menüsü | MEKSY.js")
.setThumbnail(message.author.avatarURL() ? message.author.avatarURL({dynamic: true}) : 'https://cdn.glitch.com/8e70d198-9ddc-40aa-b0c6-ccb4573f14a4%2F6499d2f1c46b106eed1e25892568aa55.png')
.setColor("#363636")
.setDescription(`
Sende **[MEKSY.js](https://discord.com/api/oauth2/authorize?client_id=1037491323076362321&permissions=8&scope=bot)**'yi Davet Etki
Bukadar Çok Komuttan Faydalanma Şansı Yakala.
`)
await message.reply({embeds: [cs], components:[link_button]}).catch(async err => {
await message.author.send({embeds: [cs]}).catch(async err => {
return console.log(`**Yardım Komutum Hata Aldı!** \`${message.guild.name}\` **Adlı Sunucuda Yetkim Olmadığı İçin Mesajı Atamıyorum.**`)
})
})

};
exports.conf = {
aliases: ["bot-davet", "botdavet", "davet-et", "davetet"]
};
exports.help = {
name: 'davet'
};