const {EmbedBuilder} = require("discord.js");

exports.run = async (client, message, args, interaction) => {

  const cm = Math.floor(Math.random(0) * 100000);

    const cs = new EmbedBuilder()
    .setColor(000001)
    .setImage('https://c.tenor.com/olRW9lie1KsAAAAC/lego-rober.gif')
    .setFooter({  text: 'HAMGON Soygun Menü!', iconURL: client.user.avatarURL({}) })
    .setDescription(`<:HangomBilet:1010490584089231420> __\`%${cm} Dolar\`__ **Çaldın!**`)
    const embed = new EmbedBuilder()
    .setColor(000001)
    .setDescription("Soyuluyor...")
    return message.channel.send({embeds : [embed]});
    setTimeout(() => { interaction.editReply({ embeds: [cs]})}, 2000);

};
exports.conf = {
  aliases: []
};

exports.help = {
  name: "soygun"
};