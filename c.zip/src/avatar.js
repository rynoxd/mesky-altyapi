const {EmbedBuilder} = require("discord.js");

exports.run = async (client, message, args) => {

    const embed = new EmbedBuilder()
    .setTitle("<:MEKSYNEWPP:1037718595972648970> Avatar | MEKSY.js")
    .setImage(message.author.avatarURL())
    .setColor("#363636")
return message.channel.send({embeds : [embed]});

};
exports.conf = {
  aliases: ["av"]
};

exports.help = {
  name: "avatar"
};