const db = require("croxydb")
exports.run = (client, message, args) => {
    if (!message.member.permissions.has("0x0000000000000004"))

return message.reply({ content: "<:hayir2:1034206492439625848> **-** \`Yönetici\` **Yetkin Olmadan Komutu Kullanamazsın.**" }).catch((err) => {})
const kanal = message.mentions.channels.first()
if(!kanal) return message.reply({content: "<:myicon20:1036329093572075671> Bir kanal etiketlemelisin."})
db.set(`gckanal_${message.guild.id}`, kanal.id)
message.reply({content: `<:myicon29:1036329116238102638> Giriş çıkış kanalı ${kanal} olarak ayarlandı`})
};
exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: []
}

exports.help = {
  name: ''
};