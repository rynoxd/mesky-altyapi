module.exports = { 
    prefix: "+",
    sahip: "1034110211386003577",
    YOUTUBE_API_KEY: "AIzaSyCX4T3FUplrAyduIFz6DeR3rt-nQVOGVsY"
}
